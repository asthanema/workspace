
function add(x, y) {
    alert('Inside add!')
    return x + y;
}
function mult(x, y) {
    alert('Inside mult!')
    return x * y;
}